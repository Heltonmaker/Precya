# PRECYÁ — Comparador de Preços para Moçambique 🇲🇿

## Visão Geral
**PRECYÁ** é uma PWA (Progressive Web App) de comparação de preços para o mercado moçambicano.
Permite aos utilizadores encontrar os melhores preços em mercados, supermercados e lojas em Maputo e outras cidades.

---

## Funcionalidades Completas

### Core
- 🔍 **Busca de produtos** com sugestões em tempo real (via `/api/suggestions`)
- 🏷️ **Comparação de preços** entre mercados (Shoprite, Mercado Central, Xipamanine, etc.)
- 📂 **Categorias**: Alimentos, Bebidas, Higiene, Limpeza, Serviços, Transporte
- 💡 **Detalhe de produto** com tabela de preços, tendências e análise IA
- 🔥 **Ofertas do dia** em carrossel horizontal

### PRECYÁ AI (Real LLM)
- 🤖 **Chat com IA real** via `/api/ai/chat` — usa Genspark proxy (modelo `gpt-5-mini`)
- 💬 Respostas em Português de Moçambique com contexto de preços reais
- 📝 Histórico de conversa (últimas 8 mensagens mantidas em contexto)
- ⚡ **Fallback inteligente** se a API não estiver disponível
- 🎯 Botões de perguntas rápidas pré-definidas

### Utilizador & Subscrição
- 🎁 **Trial gratuito de 1 dia** — ativação imediata
- 💎 **Premium Mensal — 5 MZN/mês** via M-Pesa (844 260 391 / Helton Vasco)
- 📤 Upload de comprovante de pagamento (base64, localStorage)
- ⏳ Aprovação manual pelo admin
- 🔒 Barra de estado dinâmica (trial/premium/pendente/bloqueado)

### Alertas de Preço
- 🔔 Criar alertas por produto, preço máximo e mercado
- 🗑️ Eliminar/limpar alertas individuais
- 🏷️ Badge na navegação com contagem

### Admin Panel (senha: `200500/m`)
- 📊 Dashboard com estatísticas (total, ativos, pendentes, receita MZN)
- ✅ Aprovar / ❌ Rejeitar utilizadores
- 👁️ Ver detalhes + comprovante M-Pesa
- 🗑️ Eliminar utilizadores
- 📋 Tabs: Pendentes / Activos / Trial / Rejeitados / Todos

### Extras
- 📍 **Geolocalização** com detecção de cidade (Maputo, Beira, Nampula, etc.)
- 🎤 **Busca por voz** (Web Speech API)
- 📲 **PWA install prompt** — adicionar ao ecrã inicial
- 🎨 Splash screen animada
- 🍞 Toast notifications
- 📱 Design mobile-first responsivo

---

## URLs & API

| Rota | Método | Descrição |
|------|--------|-----------|
| `/` | GET | App principal (HTML completo) |
| `/api/ai/chat` | POST | Chat com IA — `{message, history, location, products}` |
| `/api/suggestions` | GET | Sugestões de busca — `?q=termo` |
| `/api/alerts` | POST | Criar alerta — `{product, maxPrice, store}` |

---

## Stack Técnica

| Componente | Tecnologia |
|-----------|-----------|
| Runtime | Cloudflare Workers (Pages) |
| Framework | Hono v4 |
| Build | Vite 6 + @hono/vite-build |
| Frontend | HTML/CSS/JS vanilla (sem framework) |
| AI | Genspark LLM Proxy → `gpt-5-mini` |
| Dados | localStorage (users, alerts, location) |
| Estilos | CSS custom (sem Tailwind — app standalone) |
| Ícones | Font Awesome 6.5 CDN |
| Fonte | Google Fonts — Poppins |
| Dev Server | wrangler pages dev + PM2 |

---

## Estrutura de Ficheiros

```
webapp/
├── src/
│   └── index.tsx          # Worker Hono: API routes + serve HTML raw import
├── public/
│   ├── index.html         # App completa (101KB) — importada como ?raw no build
│   └── static/
│       └── style.css      # CSS extra (não usado — estilos no HTML)
├── dist/                  # Output do build (gitignored)
│   ├── _worker.js         # Worker compilado (~132KB)
│   ├── _routes.json       # Routing: /api/* → worker, resto → static
│   └── index.html         # HTML copiado para dist
├── .dev.vars              # Segredos locais (gitignored)
├── ecosystem.config.cjs   # PM2 config para dev
├── wrangler.jsonc         # Config Cloudflare Pages
├── vite.config.ts         # Build config
└── package.json
```

---

## Desenvolvimento Local

```bash
# Instalar dependências (já instaladas)
npm install

# Build
npm run build

# Iniciar servidor local (porta 3000)
pm2 start ecosystem.config.cjs

# Testar
curl http://localhost:3000/
curl http://localhost:3000/api/suggestions?q=arroz
curl -X POST http://localhost:3000/api/ai/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Olá!","history":[],"location":"Maputo","products":[]}'
```

### Variáveis de Ambiente (`.dev.vars`)
```
OPENAI_API_KEY=<genspark_token>
OPENAI_BASE_URL=https://www.genspark.ai/api/llm_proxy/v1
```

---

## Deploy Cloudflare Pages

```bash
# 1. Configurar API key
setup_cloudflare_api_key

# 2. Build
npm run build

# 3. Criar projeto (primeira vez)
npx wrangler pages project create precya --production-branch main

# 4. Deploy
npx wrangler pages deploy dist --project-name precya

# 5. Configurar segredo da IA
npx wrangler pages secret put OPENAI_API_KEY --project-name precya
npx wrangler pages secret put OPENAI_BASE_URL --project-name precya
```

---

## Dados de Teste

| Campo | Valor |
|-------|-------|
| Admin password | `200500/m` |
| M-Pesa número | `844 260 391` |
| M-Pesa titular | Helton Vasco |
| Preço subscrição | 5 MZN/mês |
| Trial | 1 dia grátis |

### Produtos Disponíveis (10)
Arroz Importado 5kg · Óleo de Cozinha 1L · Açúcar 2kg · Sabonete Nivea 90g ·
Detergente 500g · Coca-Cola 2L · Transporte Chapa · Corte de Cabelo Masc. ·
Pão Francês · Gasolina 1L

### Mercados (preços por produto)
Mercado Central Maputo · Shoprite Baixa · Continente Matola ·
Mini-Mercado Polana · Mini-Mercado Xipamanine · Mercado 25 de Junho ·
Padaria Central · Farmácia Popular · Petromoc · Galp · Total

---

## Estado do Projeto

- **Versão**: 2.0
- **Plataforma**: Cloudflare Pages
- **Status**: ✅ Funcional em desenvolvimento
- **IA**: ✅ Real LLM integrado (Genspark proxy)
- **Deploy**: ⏳ Aguarda configuração Cloudflare API key
- **Última actualização**: Maio 2025
- **Autor**: Helton Vasco
