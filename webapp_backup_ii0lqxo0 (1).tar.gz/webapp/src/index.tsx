import { Hono } from 'hono'
import { cors } from 'hono/cors'
// Import HTML as a raw string at build time — no serveStatic, no KV manifest needed
import indexHTML from '../public/index.html?raw'

type Bindings = {
  OPENAI_API_KEY: string
  OPENAI_BASE_URL: string
}

const app = new Hono<{ Bindings: Bindings }>()

// CORS for all API routes
app.use('/api/*', cors())

// ========== AI CHAT ENDPOINT ==========
app.post('/api/ai/chat', async (c) => {
  const { message, history, location, products } = await c.req.json()

  const apiKey = c.env?.OPENAI_API_KEY || ''
  const baseURL = (c.env?.OPENAI_BASE_URL || 'https://www.genspark.ai/api/llm_proxy/v1').replace(/\/$/, '')

  const productSummary = (products || []).map((p: any) => {
    const sorted = [...(p.prices || [])].sort((a: any, b: any) => a.price - b.price)
    const best = sorted[0]
    return best
      ? `${p.name}: mais barato em ${best.store} por ${best.price} MZN`
      : p.name
  }).join('\n')

  const systemPrompt = `Você é o PRECYÁ AI, assistente especializado em preços e mercados de Moçambique.
Ajude os utilizadores a encontrar os melhores preços, comparar mercados e economizar dinheiro.

Localização atual: ${location || 'Maputo'}

Produtos com preços disponíveis no sistema:
${productSummary}

Regras:
- Responda SEMPRE em Português de Moçambique
- Seja conciso, útil e amigável (máx 3-4 frases)
- Use dados reais do sistema acima quando relevante
- Dê recomendações específicas de onde comprar mais barato
- Use expressões moçambicanas quando adequado (ex: "mano", "vizinha")
- Calcule economias quando possível
- Se não souber algo, sugira usar a busca do app`

  const messages = [
    { role: 'system', content: systemPrompt },
    ...(history || []).slice(-8),
    { role: 'user', content: message }
  ]

  if (apiKey) {
    try {
      const response = await fetch(`${baseURL}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-5-mini',
          messages,
          max_tokens: 300,
          temperature: 0.7
        })
      })

      if (response.ok) {
        const data: any = await response.json()
        const reply = data.choices?.[0]?.message?.content
        if (reply) {
          return c.json({ reply, success: true })
        }
      }
    } catch (_) {
      // fall through to fallback
    }
  }

  // Intelligent fallback (no API key or API error)
  return c.json({ reply: generateFallback(message, location, products), success: true })
})

function generateFallback(message: string, location: string, products: any[]): string {
  const msg = (message || '').toLowerCase()
  const loc = location || 'Maputo'

  // Match against real product data if available
  if (products?.length) {
    for (const p of products) {
      const firstWord = (p.name || '').toLowerCase().split(' ')[0]
      if (firstWord && msg.includes(firstWord)) {
        const sorted = [...(p.prices || [])].sort((a: any, b: any) => a.price - b.price)
        const best = sorted[0]
        const worst = sorted[sorted.length - 1]
        if (best && worst && best.price !== worst.price) {
          return `Em ${loc}, ${p.name} mais barato: ${best.store} por ${best.price} MZN. Poupas ${worst.price - best.price} MZN vs o mais caro! 💰`
        }
      }
    }
  }

  if (msg.includes('arroz')) return `Em ${loc}, o arroz mais barato está no Mercado Central por 185 MZN (5kg). O Shoprite cobra 210 MZN — poupas 25 MZN! 🛒`
  if (msg.includes('leo') || msg.includes('oleo') || msg.includes('óleo')) return `O óleo de cozinha mais barato em ${loc}: Mini-Mercado Xipamanine por 90 MZN/L. O Shoprite cobra 110 MZN — diferença de 20 MZN! 💡`
  if (msg.includes('car') || msg.includes('acucar')) return `O açúcar 2kg mais barato está no Mercado 25 de Junho por 118 MZN. Poupa 17 MZN vs o Shoprite! 🎯`
  if (msg.includes('chapa') || msg.includes('transporte') || msg.includes('autocarro')) return `O chapa mais barato para o centro custa 15 MZN (Chapa 200). Evita o MyTaxi para trajetos curtos — é 10x mais caro! 🚌`
  if (msg.includes('pao') || msg.includes('pão')) return `O pão francês mais barato: Padaria Central e Mercado Central por apenas 5 MZN. A Padaria Sommerschield cobra 8 MZN! 🥖`
  if (msg.includes('gasolina') || msg.includes('combustivel')) return `A gasolina mais barata em ${loc}: Galp Matola por 76 MZN/L. O Total Av. 24 Julho cobra 80 MZN — poupa 4 MZN por litro! ⛽`
  if (msg.includes('barato') || msg.includes('economizar') || msg.includes('poupar') || msg.includes('económico')) return `Dica de ouro: o Mercado Central de ${loc} tem os melhores preços em alimentos. Compra cedo (7h-9h) para o melhor stock! 💰`
  if (msg.includes('olá') || msg.includes('ola') || msg.includes('bom dia') || msg.includes('boa tarde') || msg.includes('boa noite') || msg.includes('oi')) return `Olá! 👋 Sou o PRECYÁ AI, o teu assistente de preços em Moçambique. Pergunta-me sobre qualquer produto e digo-te onde comprar mais barato em ${loc}! 🇲🇿`
  if (msg.includes('shoprite') || msg.includes('continente') || msg.includes('supermercado')) return `Os supermercados têm boa qualidade mas os mercados locais como o Mercado Central são 15-25% mais baratos na maioria dos produtos! 🏪`
  if (msg.includes('mercado') || msg.includes('perto') || msg.includes('onde')) return `Em ${loc}, o Mercado Central na Baixa tem os melhores preços gerais. O Mini-Mercado Xipamanine é ótimo para óleos e condimentos! 📍`
  if (msg.includes('sabonete') || msg.includes('higiene')) return `O sabonete Nivea 90g mais barato: Mercado Central por 42 MZN. A Farmácia Sommerschield cobra 48 MZN — poupa 6 MZN! 🧼`
  if (msg.includes('coca') || msg.includes('refrigerante') || msg.includes('bebida')) return `A Coca-Cola 2L mais barata em ${loc}: Mini-Mercado Polana por 72 MZN. O Mercado Central cobra 80 MZN — poupas 8 MZN! 🥤`

  const tips = [
    `Boa pergunta! Usa a busca do app para ver preços actualizados de mais de 10 produtos em ${loc}. 🔍`,
    `Em ${loc}, os melhores preços estão nos mercados locais — 15 a 25% mais baratos que supermercados! 💡`,
    `Para encontrar os melhores preços, usa a função de busca do PRECYÁ. Tenho dados de vários mercados em ${loc}! 📊`
  ]
  return tips[Math.floor(Math.random() * tips.length)]
}

// ========== SUGGESTIONS ENDPOINT ==========
app.get('/api/suggestions', (c) => {
  const query = (c.req.query('q') || '').toLowerCase()
  const all = [
    'Arroz Importado 5kg', 'Óleo de Cozinha 1L', 'Açúcar 2kg',
    'Sabonete Nivea 90g', 'Detergente 500g', 'Coca-Cola 2L',
    'Transporte Chapa', 'Corte de Cabelo Masc.', 'Pão Francês', 'Gasolina 1L',
    'Feijão 1kg', 'Farinha de Milho 2kg', 'Leite 1L', 'Ovos 12un',
    'Frango Inteiro', 'Tomate 1kg', 'Cebola 1kg', 'Batata 2kg'
  ]
  const suggestions = query
    ? all.filter(s => s.toLowerCase().includes(query))
    : all.slice(0, 6)
  return c.json({ suggestions })
})

// ========== PRICE ALERT ENDPOINT ==========
app.post('/api/alerts', async (c) => {
  const body = await c.req.json()
  return c.json({ success: true, message: 'Alerta configurado com sucesso!', alert: body })
})

// ========== SERVE INDEX.HTML FOR ALL OTHER ROUTES ==========
// HTML is imported as a raw string at build time via Vite's ?raw suffix.
// This works perfectly in Cloudflare Workers — no KV manifest, no serveStatic needed.
app.get('*', (c) => {
  return c.html(indexHTML)
})

export default app
